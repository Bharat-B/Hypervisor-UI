<template>

</template>
<script>
export default {
	layout: 'admin',
	head: {
		title: 'My Account'
	},
	data() {
		return {}
	},
	asyncData() {

	},
	mounted() {

	}
}
</script>
