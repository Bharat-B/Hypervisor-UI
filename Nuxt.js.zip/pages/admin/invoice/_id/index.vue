<template>

</template>
<script>
export default {
	layout: 'admin',
	head: {
		title: 'Show Invoice'
	},
	data() {
		return {}
	},
	asyncData() {

	},
	mounted() {

	}
}
</script>
