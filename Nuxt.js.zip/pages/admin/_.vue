<template>

</template>
<script>
export default {
	asyncData({redirect}) {
		return redirect('/admin/dashboard');
	}
}
</script>
