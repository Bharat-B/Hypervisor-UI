<template>

</template>
<script>
export default {
	layout: 'admin',
	data() {
		return {
			domains: []
		}
	},
	asyncData({$axios, route}) {

	}
}
</script>
