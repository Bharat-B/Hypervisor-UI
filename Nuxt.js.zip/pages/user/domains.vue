<template>

</template>
<script>
export default {
	layout: 'user'
}
</script>
