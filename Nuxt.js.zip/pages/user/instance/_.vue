<template>

</template>
<script>
export default {
	asyncData({redirect}) {
		return redirect('/user/dashboard');
	}
}
</script>
