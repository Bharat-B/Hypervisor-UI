<template>

</template>
<script>
export default {
	asyncData({redirect}) {
		return redirect('/user/domains');
	}
}
</script>
