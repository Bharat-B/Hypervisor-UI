<template>
	<div class="dashcontent">
		<h1>Sorry, we're down for maintainence.</h1>
		<p>Your services are running perfectly fine!</p>
	</div>
</template>
<script>
export default {
	layout: 'user',
	head: {
		title: 'Maintenance'
	},
}
</script>
