<template>

</template>
<script>
export default {
	asyncData({redirect}) {
		return redirect('/login');
	}
}
</script>
