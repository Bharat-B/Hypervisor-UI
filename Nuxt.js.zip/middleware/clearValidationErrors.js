export default function({ store }) {
    store.dispatch('clearErrors');
}