import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _73fedfe7 = () => interopDefault(import('..\\pages\\forgot\\index.vue' /* webpackChunkName: "pages/forgot/index" */))
const _1ae34bc6 = () => interopDefault(import('..\\pages\\forgot-password.vue' /* webpackChunkName: "pages/forgot-password" */))
const _12e3c581 = () => interopDefault(import('..\\pages\\login.vue' /* webpackChunkName: "pages/login" */))
const _42b22480 = () => interopDefault(import('..\\pages\\mfa.vue' /* webpackChunkName: "pages/mfa" */))
const _1354508a = () => interopDefault(import('..\\pages\\register.vue' /* webpackChunkName: "pages/register" */))
const _0c2276d2 = () => interopDefault(import('..\\pages\\signup\\index.vue' /* webpackChunkName: "pages/signup/index" */))
const _914e2706 = () => interopDefault(import('..\\pages\\admin\\dashboard.vue' /* webpackChunkName: "pages/admin/dashboard" */))
const _79fdd699 = () => interopDefault(import('..\\pages\\admin\\distros.vue' /* webpackChunkName: "pages/admin/distros" */))
const _2698a0d8 = () => interopDefault(import('..\\pages\\admin\\domains.vue' /* webpackChunkName: "pages/admin/domains" */))
const _401307be = () => interopDefault(import('..\\pages\\admin\\emails.vue' /* webpackChunkName: "pages/admin/emails" */))
const _933fe436 = () => interopDefault(import('..\\pages\\admin\\hypervisors.vue' /* webpackChunkName: "pages/admin/hypervisors" */))
const _adc431a6 = () => interopDefault(import('..\\pages\\admin\\image-groups.vue' /* webpackChunkName: "pages/admin/image-groups" */))
const _c90b2d42 = () => interopDefault(import('..\\pages\\admin\\images.vue' /* webpackChunkName: "pages/admin/images" */))
const _e0ac0932 = () => interopDefault(import('..\\pages\\admin\\instances.vue' /* webpackChunkName: "pages/admin/instances" */))
const _d37569e6 = () => interopDefault(import('..\\pages\\admin\\invoices.vue' /* webpackChunkName: "pages/admin/invoices" */))
const _d30ba796 = () => interopDefault(import('..\\pages\\admin\\isos.vue' /* webpackChunkName: "pages/admin/isos" */))
const _9938a168 = () => interopDefault(import('..\\pages\\admin\\migrations.vue' /* webpackChunkName: "pages/admin/migrations" */))
const _657526a8 = () => interopDefault(import('..\\pages\\admin\\networks.vue' /* webpackChunkName: "pages/admin/networks" */))
const _9e608858 = () => interopDefault(import('..\\pages\\admin\\payments.vue' /* webpackChunkName: "pages/admin/payments" */))
const _f3e35c5a = () => interopDefault(import('..\\pages\\admin\\plans.vue' /* webpackChunkName: "pages/admin/plans" */))
const _29ed1952 = () => interopDefault(import('..\\pages\\admin\\profile.vue' /* webpackChunkName: "pages/admin/profile" */))
const _79dfa6b0 = () => interopDefault(import('..\\pages\\admin\\regions.vue' /* webpackChunkName: "pages/admin/regions" */))
const _6a7b20b6 = () => interopDefault(import('..\\pages\\admin\\reseller-plans.vue' /* webpackChunkName: "pages/admin/reseller-plans" */))
const _2586046c = () => interopDefault(import('..\\pages\\admin\\settings.vue' /* webpackChunkName: "pages/admin/settings" */))
const _03ecac7f = () => interopDefault(import('..\\pages\\admin\\storages.vue' /* webpackChunkName: "pages/admin/storages" */))
const _1384c0f7 = () => interopDefault(import('..\\pages\\admin\\tasks.vue' /* webpackChunkName: "pages/admin/tasks" */))
const _1cf90671 = () => interopDefault(import('..\\pages\\admin\\users.vue' /* webpackChunkName: "pages/admin/users" */))
const _a29b454c = () => interopDefault(import('..\\pages\\user\\billing\\index.vue' /* webpackChunkName: "pages/user/billing/index" */))
const _cc3f06fe = () => interopDefault(import('..\\pages\\user\\dashboard.vue' /* webpackChunkName: "pages/user/dashboard" */))
const _570c61dc = () => interopDefault(import('..\\pages\\user\\domains.vue' /* webpackChunkName: "pages/user/domains" */))
const _0b0ba440 = () => interopDefault(import('..\\pages\\user\\firewalls.vue' /* webpackChunkName: "pages/user/firewalls" */))
const _86fac60e = () => interopDefault(import('..\\pages\\user\\maintainence.vue' /* webpackChunkName: "pages/user/maintainence" */))
const _5a60da56 = () => interopDefault(import('..\\pages\\user\\profile.vue' /* webpackChunkName: "pages/user/profile" */))
const _7006615c = () => interopDefault(import('..\\pages\\user\\recipes.vue' /* webpackChunkName: "pages/user/recipes" */))
const _0c01af9c = () => interopDefault(import('..\\pages\\user\\snapshots.vue' /* webpackChunkName: "pages/user/snapshots" */))
const _6fb88cbc = () => interopDefault(import('..\\pages\\user\\ssh-keys.vue' /* webpackChunkName: "pages/user/ssh-keys" */))
const _73c0032a = () => interopDefault(import('..\\pages\\user\\subusers.vue' /* webpackChunkName: "pages/user/subusers" */))
const _192f6046 = () => interopDefault(import('..\\pages\\admin\\distro\\create.vue' /* webpackChunkName: "pages/admin/distro/create" */))
const _7beac90c = () => interopDefault(import('..\\pages\\admin\\hypervisor\\create.vue' /* webpackChunkName: "pages/admin/hypervisor/create" */))
const _71e97d9c = () => interopDefault(import('..\\pages\\admin\\image-group\\create.vue' /* webpackChunkName: "pages/admin/image-group/create" */))
const _0067d5e6 = () => interopDefault(import('..\\pages\\admin\\image\\add.vue' /* webpackChunkName: "pages/admin/image/add" */))
const _cf643bd8 = () => interopDefault(import('..\\pages\\admin\\image\\browser.vue' /* webpackChunkName: "pages/admin/image/browser" */))
const _57f342c0 = () => interopDefault(import('..\\pages\\admin\\image\\create.vue' /* webpackChunkName: "pages/admin/image/create" */))
const _68f65090 = () => interopDefault(import('..\\pages\\admin\\instance\\create.vue' /* webpackChunkName: "pages/admin/instance/create" */))
const _1d559d1f = () => interopDefault(import('..\\pages\\admin\\instance\\migrate.vue' /* webpackChunkName: "pages/admin/instance/migrate" */))
const _62b54ef0 = () => interopDefault(import('..\\pages\\admin\\ipv4\\create.vue' /* webpackChunkName: "pages/admin/ipv4/create" */))
const _a8a934ec = () => interopDefault(import('..\\pages\\admin\\ipv6\\create.vue' /* webpackChunkName: "pages/admin/ipv6/create" */))
const _4a50c32a = () => interopDefault(import('..\\pages\\admin\\iso\\create.vue' /* webpackChunkName: "pages/admin/iso/create" */))
const _7e095ed3 = () => interopDefault(import('..\\pages\\admin\\network\\create.vue' /* webpackChunkName: "pages/admin/network/create" */))
const _14b2afcc = () => interopDefault(import('..\\pages\\admin\\plan\\create.vue' /* webpackChunkName: "pages/admin/plan/create" */))
const _d9bc2952 = () => interopDefault(import('..\\pages\\admin\\region\\create.vue' /* webpackChunkName: "pages/admin/region/create" */))
const _24e628ee = () => interopDefault(import('..\\pages\\admin\\reseller-plan\\create.vue' /* webpackChunkName: "pages/admin/reseller-plan/create" */))
const _53b588c0 = () => interopDefault(import('..\\pages\\admin\\storage\\create.vue' /* webpackChunkName: "pages/admin/storage/create" */))
const _330f2d6e = () => interopDefault(import('..\\pages\\admin\\user\\create.vue' /* webpackChunkName: "pages/admin/user/create" */))
const _aa32c9c2 = () => interopDefault(import('..\\pages\\user\\firewall\\create.vue' /* webpackChunkName: "pages/user/firewall/create" */))
const _c8400998 = () => interopDefault(import('..\\pages\\user\\instance\\create.vue' /* webpackChunkName: "pages/user/instance/create" */))
const _7ecec92f = () => interopDefault(import('..\\pages\\user\\instance\\reseller-create.vue' /* webpackChunkName: "pages/user/instance/reseller-create" */))
const _32ba5526 = () => interopDefault(import('..\\pages\\user\\recipe\\create.vue' /* webpackChunkName: "pages/user/recipe/create" */))
const _370e243a = () => interopDefault(import('..\\pages\\user\\snapshot\\create.vue' /* webpackChunkName: "pages/user/snapshot/create" */))
const _67e50cc3 = () => interopDefault(import('..\\pages\\user\\ssh-key\\create.vue' /* webpackChunkName: "pages/user/ssh-key/create" */))
const _714baf98 = () => interopDefault(import('..\\pages\\user\\subuser\\create.vue' /* webpackChunkName: "pages/user/subuser/create" */))
const _27cfa88d = () => interopDefault(import('..\\pages\\user\\billing\\invoice\\_id\\index.vue' /* webpackChunkName: "pages/user/billing/invoice/_id/index" */))
const _c0b8298c = () => interopDefault(import('..\\pages\\user\\billing\\invoice\\_.vue' /* webpackChunkName: "pages/user/billing/invoice/_" */))
const _278542bc = () => interopDefault(import('..\\pages\\admin\\distro\\_id\\index.vue' /* webpackChunkName: "pages/admin/distro/_id/index" */))
const _145c745d = () => interopDefault(import('..\\pages\\admin\\email\\_id\\index.vue' /* webpackChunkName: "pages/admin/email/_id/index" */))
const _1c404054 = () => interopDefault(import('..\\pages\\admin\\hypervisor\\_id\\index.vue' /* webpackChunkName: "pages/admin/hypervisor/_id/index" */))
const _d3b22ce4 = () => interopDefault(import('..\\pages\\admin\\image-group\\_id\\index.vue' /* webpackChunkName: "pages/admin/image-group/_id/index" */))
const _ee1117c8 = () => interopDefault(import('..\\pages\\admin\\image\\_id\\index.vue' /* webpackChunkName: "pages/admin/image/_id/index" */))
const _017465d8 = () => interopDefault(import('..\\pages\\admin\\instance\\_id\\index.vue' /* webpackChunkName: "pages/admin/instance/_id/index" */))
const _290459ae = () => interopDefault(import('..\\pages\\admin\\invoice\\_id\\index.vue' /* webpackChunkName: "pages/admin/invoice/_id/index" */))
const _166aaf86 = () => interopDefault(import('..\\pages\\admin\\iso\\_id\\index.vue' /* webpackChunkName: "pages/admin/iso/_id/index" */))
const _3fab4eaf = () => interopDefault(import('..\\pages\\admin\\network\\_id\\index.vue' /* webpackChunkName: "pages/admin/network/_id/index" */))
const _623d09b0 = () => interopDefault(import('..\\pages\\admin\\plan\\_id\\index.vue' /* webpackChunkName: "pages/admin/plan/_id/index" */))
const _763c0d9a = () => interopDefault(import('..\\pages\\admin\\region\\_id\\index.vue' /* webpackChunkName: "pages/admin/region/_id/index" */))
const _16e4df36 = () => interopDefault(import('..\\pages\\admin\\reseller-plan\\_id\\index.vue' /* webpackChunkName: "pages/admin/reseller-plan/_id/index" */))
const _39c1fcfc = () => interopDefault(import('..\\pages\\admin\\storage\\_id\\index.vue' /* webpackChunkName: "pages/admin/storage/_id/index" */))
const _49a257ca = () => interopDefault(import('..\\pages\\admin\\user\\_id\\index.vue' /* webpackChunkName: "pages/admin/user/_id/index" */))
const _f3f156e8 = () => interopDefault(import('..\\pages\\forgot\\verify\\_id\\index.vue' /* webpackChunkName: "pages/forgot/verify/_id/index" */))
const _6d00d8fe = () => interopDefault(import('..\\pages\\signup\\verify\\_id\\index.vue' /* webpackChunkName: "pages/signup/verify/_id/index" */))
const _518168ba = () => interopDefault(import('..\\pages\\user\\domain\\_id.vue' /* webpackChunkName: "pages/user/domain/_id" */))
const _07b984fb = () => interopDefault(import('..\\pages\\user\\firewall\\_id\\index.vue' /* webpackChunkName: "pages/user/firewall/_id/index" */))
const _1e2ad290 = () => interopDefault(import('..\\pages\\user\\instance\\_id\\index.vue' /* webpackChunkName: "pages/user/instance/_id/index" */))
const _3b13e849 = () => interopDefault(import('..\\pages\\user\\recipe\\_id\\index.vue' /* webpackChunkName: "pages/user/recipe/_id/index" */))
const _571e849f = () => interopDefault(import('..\\pages\\user\\ssh-key\\_id\\index.vue' /* webpackChunkName: "pages/user/ssh-key/_id/index" */))
const _76c67f90 = () => interopDefault(import('..\\pages\\user\\subuser\\_id\\index.vue' /* webpackChunkName: "pages/user/subuser/_id/index" */))
const _5436c013 = () => interopDefault(import('..\\pages\\admin\\instance\\_id\\manage.vue' /* webpackChunkName: "pages/admin/instance/_id/manage" */))
const _3754dbce = () => interopDefault(import('..\\pages\\admin\\network\\_id\\ips\\index.vue' /* webpackChunkName: "pages/admin/network/_id/ips/index" */))
const _4871c7fe = () => interopDefault(import('..\\pages\\user\\recipe\\_.vue' /* webpackChunkName: "pages/user/recipe/_" */))
const _1f985a30 = () => interopDefault(import('..\\pages\\user\\ssh-key\\_.vue' /* webpackChunkName: "pages/user/ssh-key/_" */))
const _c2808470 = () => interopDefault(import('..\\pages\\user\\snapshot\\_.vue' /* webpackChunkName: "pages/user/snapshot/_" */))
const _3867e1d7 = () => interopDefault(import('..\\pages\\user\\instance\\_.vue' /* webpackChunkName: "pages/user/instance/_" */))
const _51e6e008 = () => interopDefault(import('..\\pages\\user\\domain\\_.vue' /* webpackChunkName: "pages/user/domain/_" */))
const _5ddc89e8 = () => interopDefault(import('..\\pages\\user\\firewall\\_.vue' /* webpackChunkName: "pages/user/firewall/_" */))
const _0984d9cc = () => interopDefault(import('..\\pages\\user\\_.vue' /* webpackChunkName: "pages/user/_" */))
const _ea09f470 = () => interopDefault(import('..\\pages\\admin\\_.vue' /* webpackChunkName: "pages/admin/_" */))
const _493c226a = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _e37f2912 = () => interopDefault(import('..\\pages\\_.vue' /* webpackChunkName: "pages/_" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/forgot",
    component: _73fedfe7,
    name: "forgot"
  }, {
    path: "/forgot-password",
    component: _1ae34bc6,
    name: "forgot-password"
  }, {
    path: "/login",
    component: _12e3c581,
    name: "login"
  }, {
    path: "/mfa",
    component: _42b22480,
    name: "mfa"
  }, {
    path: "/register",
    component: _1354508a,
    name: "register"
  }, {
    path: "/signup",
    component: _0c2276d2,
    name: "signup"
  }, {
    path: "/admin/dashboard",
    component: _914e2706,
    name: "admin-dashboard"
  }, {
    path: "/admin/distros",
    component: _79fdd699,
    name: "admin-distros"
  }, {
    path: "/admin/domains",
    component: _2698a0d8,
    name: "admin-domains"
  }, {
    path: "/admin/emails",
    component: _401307be,
    name: "admin-emails"
  }, {
    path: "/admin/hypervisors",
    component: _933fe436,
    name: "admin-hypervisors"
  }, {
    path: "/admin/image-groups",
    component: _adc431a6,
    name: "admin-image-groups"
  }, {
    path: "/admin/images",
    component: _c90b2d42,
    name: "admin-images"
  }, {
    path: "/admin/instances",
    component: _e0ac0932,
    name: "admin-instances"
  }, {
    path: "/admin/invoices",
    component: _d37569e6,
    name: "admin-invoices"
  }, {
    path: "/admin/isos",
    component: _d30ba796,
    name: "admin-isos"
  }, {
    path: "/admin/migrations",
    component: _9938a168,
    name: "admin-migrations"
  }, {
    path: "/admin/networks",
    component: _657526a8,
    name: "admin-networks"
  }, {
    path: "/admin/payments",
    component: _9e608858,
    name: "admin-payments"
  }, {
    path: "/admin/plans",
    component: _f3e35c5a,
    name: "admin-plans"
  }, {
    path: "/admin/profile",
    component: _29ed1952,
    name: "admin-profile"
  }, {
    path: "/admin/regions",
    component: _79dfa6b0,
    name: "admin-regions"
  }, {
    path: "/admin/reseller-plans",
    component: _6a7b20b6,
    name: "admin-reseller-plans"
  }, {
    path: "/admin/settings",
    component: _2586046c,
    name: "admin-settings"
  }, {
    path: "/admin/storages",
    component: _03ecac7f,
    name: "admin-storages"
  }, {
    path: "/admin/tasks",
    component: _1384c0f7,
    name: "admin-tasks"
  }, {
    path: "/admin/users",
    component: _1cf90671,
    name: "admin-users"
  }, {
    path: "/user/billing",
    component: _a29b454c,
    name: "user-billing"
  }, {
    path: "/user/dashboard",
    component: _cc3f06fe,
    name: "user-dashboard"
  }, {
    path: "/user/domains",
    component: _570c61dc,
    name: "user-domains"
  }, {
    path: "/user/firewalls",
    component: _0b0ba440,
    name: "user-firewalls"
  }, {
    path: "/user/maintainence",
    component: _86fac60e,
    name: "user-maintainence"
  }, {
    path: "/user/profile",
    component: _5a60da56,
    name: "user-profile"
  }, {
    path: "/user/recipes",
    component: _7006615c,
    name: "user-recipes"
  }, {
    path: "/user/snapshots",
    component: _0c01af9c,
    name: "user-snapshots"
  }, {
    path: "/user/ssh-keys",
    component: _6fb88cbc,
    name: "user-ssh-keys"
  }, {
    path: "/user/subusers",
    component: _73c0032a,
    name: "user-subusers"
  }, {
    path: "/admin/distro/create",
    component: _192f6046,
    name: "admin-distro-create"
  }, {
    path: "/admin/hypervisor/create",
    component: _7beac90c,
    name: "admin-hypervisor-create"
  }, {
    path: "/admin/image-group/create",
    component: _71e97d9c,
    name: "admin-image-group-create"
  }, {
    path: "/admin/image/add",
    component: _0067d5e6,
    name: "admin-image-add"
  }, {
    path: "/admin/image/browser",
    component: _cf643bd8,
    name: "admin-image-browser"
  }, {
    path: "/admin/image/create",
    component: _57f342c0,
    name: "admin-image-create"
  }, {
    path: "/admin/instance/create",
    component: _68f65090,
    name: "admin-instance-create"
  }, {
    path: "/admin/instance/migrate",
    component: _1d559d1f,
    name: "admin-instance-migrate"
  }, {
    path: "/admin/ipv4/create",
    component: _62b54ef0,
    name: "admin-ipv4-create"
  }, {
    path: "/admin/ipv6/create",
    component: _a8a934ec,
    name: "admin-ipv6-create"
  }, {
    path: "/admin/iso/create",
    component: _4a50c32a,
    name: "admin-iso-create"
  }, {
    path: "/admin/network/create",
    component: _7e095ed3,
    name: "admin-network-create"
  }, {
    path: "/admin/plan/create",
    component: _14b2afcc,
    name: "admin-plan-create"
  }, {
    path: "/admin/region/create",
    component: _d9bc2952,
    name: "admin-region-create"
  }, {
    path: "/admin/reseller-plan/create",
    component: _24e628ee,
    name: "admin-reseller-plan-create"
  }, {
    path: "/admin/storage/create",
    component: _53b588c0,
    name: "admin-storage-create"
  }, {
    path: "/admin/user/create",
    component: _330f2d6e,
    name: "admin-user-create"
  }, {
    path: "/user/firewall/create",
    component: _aa32c9c2,
    name: "user-firewall-create"
  }, {
    path: "/user/instance/create",
    component: _c8400998,
    name: "user-instance-create"
  }, {
    path: "/user/instance/reseller-create",
    component: _7ecec92f,
    name: "user-instance-reseller-create"
  }, {
    path: "/user/recipe/create",
    component: _32ba5526,
    name: "user-recipe-create"
  }, {
    path: "/user/snapshot/create",
    component: _370e243a,
    name: "user-snapshot-create"
  }, {
    path: "/user/ssh-key/create",
    component: _67e50cc3,
    name: "user-ssh-key-create"
  }, {
    path: "/user/subuser/create",
    component: _714baf98,
    name: "user-subuser-create"
  }, {
    path: "/user/billing/invoice/:id",
    component: _27cfa88d,
    name: "user-billing-invoice-id"
  }, {
    path: "/user/billing/invoice/*",
    component: _c0b8298c,
    name: "user-billing-invoice-all"
  }, {
    path: "/admin/distro/:id",
    component: _278542bc,
    name: "admin-distro-id"
  }, {
    path: "/admin/email/:id",
    component: _145c745d,
    name: "admin-email-id"
  }, {
    path: "/admin/hypervisor/:id",
    component: _1c404054,
    name: "admin-hypervisor-id"
  }, {
    path: "/admin/image-group/:id",
    component: _d3b22ce4,
    name: "admin-image-group-id"
  }, {
    path: "/admin/image/:id",
    component: _ee1117c8,
    name: "admin-image-id"
  }, {
    path: "/admin/instance/:id",
    component: _017465d8,
    name: "admin-instance-id"
  }, {
    path: "/admin/invoice/:id",
    component: _290459ae,
    name: "admin-invoice-id"
  }, {
    path: "/admin/iso/:id",
    component: _166aaf86,
    name: "admin-iso-id"
  }, {
    path: "/admin/network/:id",
    component: _3fab4eaf,
    name: "admin-network-id"
  }, {
    path: "/admin/plan/:id",
    component: _623d09b0,
    name: "admin-plan-id"
  }, {
    path: "/admin/region/:id",
    component: _763c0d9a,
    name: "admin-region-id"
  }, {
    path: "/admin/reseller-plan/:id",
    component: _16e4df36,
    name: "admin-reseller-plan-id"
  }, {
    path: "/admin/storage/:id",
    component: _39c1fcfc,
    name: "admin-storage-id"
  }, {
    path: "/admin/user/:id",
    component: _49a257ca,
    name: "admin-user-id"
  }, {
    path: "/forgot/verify/:id",
    component: _f3f156e8,
    name: "forgot-verify-id"
  }, {
    path: "/signup/verify/:id",
    component: _6d00d8fe,
    name: "signup-verify-id"
  }, {
    path: "/user/domain/:id?",
    component: _518168ba,
    name: "user-domain-id"
  }, {
    path: "/user/firewall/:id",
    component: _07b984fb,
    name: "user-firewall-id"
  }, {
    path: "/user/instance/:id",
    component: _1e2ad290,
    name: "user-instance-id"
  }, {
    path: "/user/recipe/:id",
    component: _3b13e849,
    name: "user-recipe-id"
  }, {
    path: "/user/ssh-key/:id",
    component: _571e849f,
    name: "user-ssh-key-id"
  }, {
    path: "/user/subuser/:id",
    component: _76c67f90,
    name: "user-subuser-id"
  }, {
    path: "/admin/instance/:id?/manage",
    component: _5436c013,
    name: "admin-instance-id-manage"
  }, {
    path: "/admin/network/:id?/ips",
    component: _3754dbce,
    name: "admin-network-id-ips"
  }, {
    path: "/user/recipe/*",
    component: _4871c7fe,
    name: "user-recipe-all"
  }, {
    path: "/user/ssh-key/*",
    component: _1f985a30,
    name: "user-ssh-key-all"
  }, {
    path: "/user/snapshot/*",
    component: _c2808470,
    name: "user-snapshot-all"
  }, {
    path: "/user/instance/*",
    component: _3867e1d7,
    name: "user-instance-all"
  }, {
    path: "/user/domain/*",
    component: _51e6e008,
    name: "user-domain-all"
  }, {
    path: "/user/firewall/*",
    component: _5ddc89e8,
    name: "user-firewall-all"
  }, {
    path: "/user/*",
    component: _0984d9cc,
    name: "user-all"
  }, {
    path: "/admin/*",
    component: _ea09f470,
    name: "admin-all"
  }, {
    path: "/",
    component: _493c226a,
    name: "index"
  }, {
    path: "/*",
    component: _e37f2912,
    name: "all"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
